import random

import pygame


class Blob_1:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        # 1 == "pink"
        # 2 == "blue"
        # 3 == "green"
        # 4 == "yellow"
        if color == 1:
            self.image = pygame.image.load("Untitled-3-removebg-preview.png")
        if color == 2:
            self.image = pygame.image.load("Untitled-3_copy-removebg-preview.png")
        if color == 3:
            self.image = pygame.image.load("Untitled-3_copy_2-removebg-preview.png")
        if color == 4:
            self.image = pygame.image.load("Untitled-3_copy_4-removebg-preview.png")
        self.image_size = self.image.get_size()
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0], self.image_size[1])

    def move(self, new_x, new_y):
        self.x = new_x
        self.y = new_y
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0], self.image_size[1])

randomizer_list = []

randomizer_list.append(Blob_1(random.randint(50, 150), 40, random.randint(1, 4)))
randomizer_list.append(Blob_1(random.randint(200, 300), 40, random.randint(1, 4)))
randomizer_list.append(Blob_1(random.randint(350, 450), 40, random.randint(1, 4)))
randomizer_list.append(Blob_1(random.randint(500, 600), 40, random.randint(1, 4)))


