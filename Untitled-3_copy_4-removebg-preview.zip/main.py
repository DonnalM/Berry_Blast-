import pygame
import random
from blob import Blob_1


# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Times New Roman', 20)
pygame.display.set_caption("Party Poppers!")

# set up variables for the display
SCREEN_HEIGHT = 530
SCREEN_WIDTH = 700
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)
r = 240
g = 225
b = 48

# render the text for later
message = "Click the matching blocks to score!"
display_message = my_font.render(message, True, (0,0,0))


blob = Blob_1(50, 40, 1)
blob_two = Blob_1(150, 40, 2)
blob_three = Blob_1(250, 40, 3)
blob_four = Blob_1(350, 40, 4)



# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True

# -------- Main Program Loop -----------
while run:
        # --- Main event loop
        ## ----- NO BLIT ZONE START ----- ##
        for event in pygame.event.get():  # User did something
            if event.type == pygame.QUIT:  # If user clicked close
                run = False
            if event.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                if blob.rect.collidepoint(pos):
                    blob.move(random.randint(90, 260), random.randint(90, 260))



        #if [placeholder, add new timer that resets every second] == 1:



        ##  ----- NO BLIT ZONE END  ----- ##

        ## FILL SCREEN, and BLIT here ##
        screen.fill((r, g, b))
        screen.blit(display_message, (0, 0))
        screen.blit(blob.image, blob.rect)
        screen.blit(blob_two.image, blob_two.rect)
        screen.blit(blob_three.image, blob_three.rect)
        screen.blit(blob_four.image, blob_four.rect)
        pygame.display.update()
 ## END OF WHILE LOOP

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()
